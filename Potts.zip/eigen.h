/*************************************************************************
 > File Name: eigen.h
 > Author: Hu Gaoke
 > Mail: hugaoke@126.com 
 > Version:No:1. 
 > Created Time: 2017年03月22日 星期三 21时38分31秒
 > Description:   
*************************************************************************/

#ifndef __EIGEN_H__
#define __EIGEN_H__

#include <iostream>
#include <fstream>
#include <cstring>
#include "Eigen/Eigenvalues"

using namespace std;
using namespace Eigen;

MatrixXd getMatrixFile(int row, int col, string fname,string faddress=""){
    string name=faddress+fname;
    ifstream fin(name.c_str());
    if(!fin.is_open()){
        cerr<<"Can't open the file: "<<name<<endl;
        exit( -1);
    }
    MatrixXd matrix=MatrixXd::Constant(row,col,0);
    int count=0;
    for(int i=0; i<row; i++){
        for(int j=0; j<col; j++)
            fin>>matrix(i,j);
        if('\n'!=fin.peek() && !fin.eof()){
            cerr<<"Wrong column number!"<<endl;
            exit( -2);
        }
        if(fin.eof() && i != row-1){
            cerr<<"Wrong row number!"<<endl;
            exit (-3);
        }
    }
    if(!fin.eof()){
        cerr<<"Wrong row number!"<<endl;
        exit (-3);
    }
    fin.close();
    return matrix;
}

MatrixXd getMatrixFile(int row, string fname,string faddress=""){
    return getMatrixFile(row, row, fname, faddress);
}

#endif                                       // __EIGEN_H__

