#include <math.h>
#include <stdio.h>
#include <float.h>
#include <iostream>
#include <string.h>
#include <fstream>
#include <mpi.h>
#include <iomanip>
#include <stdlib.h>
#include "mt19937ar.h"
#include "eigen.h"

#define L 64
#define N (L*L)
#define XNN 1
#define YNN L
#define K_B 1
#define J 1.0 
#define MC_strps_persite 51000
#define SpanTime 51
#define Q 5
#define Pi 3.14159265358979323846

int s[N];
double Temperature;
double beta;
double padd;
double matrix[MC_strps_persite/SpanTime][N];
double Tmatrix[N][MC_strps_persite/SpanTime];
double Connectmatrix[MC_strps_persite/SpanTime][MC_strps_persite/SpanTime];



void step()
{
	int i;
	int sp;
	int oldspin, newspin;
	int current, nn;
	int stack[N];

	/* Choose the seed spin for the cluster,
	 * put it on the stack, and flip it
	 */

	i = N*genrand_real3();
	//printf("%d\n",i);

	stack[0] = i;
	sp = 1;
	oldspin = s[i];
	for(;(newspin = (int)(Q*genrand_real3()))==oldspin;)
	{}
	s[i] = newspin;

	while(sp){

		/* Pull a site off the stack */

		current = stack[--sp];

		/* Check the neighbors */

		if((nn=current+XNN)>=N)
			nn -= N;
		if(s[nn]==oldspin)
			if(genrand_real1()<padd){
				stack[sp++] = nn;
				s[nn] = newspin;
			}

		if((nn=current-XNN)<0)
			nn += N;
		if(s[nn]==oldspin)
			if(genrand_real1()<padd){
				stack[sp++] = nn;
				s[nn] = newspin;
			}

		if((nn=current+YNN)>=N)
			nn -=N;
		if(s[nn]==oldspin)
			if(genrand_real1()<padd){
				stack[sp++] = nn;
				s[nn] = newspin;
			}

		if((nn=current-YNN)<0)
			nn += N;
		if(s[nn]==oldspin)
			if(genrand_real1()<padd){
				stack[sp++] = nn;
				s[nn] = newspin;
			}
	}
	/*for(int n=0;n<N;n++){
		printf("%d ",s[n]);
			if(((n+1)%L)==0)
			printf("\n");
			}
	printf("\n\n");*/
}

void Qtransfer()
{
	int n,m; double a;
	for(n=0;n<(MC_strps_persite/SpanTime);n++){
		for(m=0;m<N;m++){
			a = 2*(Pi/Q)*matrix[n][m];
			matrix[n][m] = a;
			}
		}
}

double dinfmul(double a, double b)
{
	return cos(a-b);
}		

void Mulmatrix()
{
	int i,m,k;
	for(i=0;i<MC_strps_persite/SpanTime;i++){
		for(m=0;m<MC_strps_persite/SpanTime;m++){
			for(k=0;k<N;k++){
				Connectmatrix[i][m] = Connectmatrix[i][m] + dinfmul(matrix[i][k],matrix[m][k]);
			}
			Connectmatrix[i][m] = (Connectmatrix[i][m])/N;
		}
	}
}




int main(void)
{
	double Mag=0.0; double order; int m,n,i,tt; double bat; int Pick; double magnetization; double sum;

	int npes,myrank;
    MPI_Init(NULL,NULL); 
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &npes);

	unsigned long init[4]={0x523, 0x234, 0x345, 0x456}, length=4;
    for(int j=0;j<4;j++){
        init[j]+=(time(NULL)+myrank);
    }
    init_by_array(init, length);

	for(n=0; n<N;n++)
		s[n] = (int)(Q*genrand_real3());
	
	char filename[30]={0},num[5]={0};

  	strcpy(filename,"file");

  	sprintf(num, "%d", myrank); 

 	strcat(filename,num);

  	strcat(filename,".txt");
  	ofstream outfile(filename);


	for(Temperature=0.83; Temperature<0.88;Temperature = Temperature + 0.005){

		beta =  1.0/(K_B*Temperature); 
		padd = (1.0-exp(-beta*J));
		
		for(tt=0; tt<=10000; tt++)
			step();

		Pick = 0; sum = 0; 

		for(i=0,m=0; i<=MC_strps_persite; i++){
			step();

			if(i == (Pick+1)*SpanTime){
				
				for(n=0; n<N; n++)
					matrix[m][n] =(double) s[n];
					
				m++;Pick++;
			}
		}

		int k,l;

		Qtransfer();

		for(k = 0;k<MC_strps_persite/SpanTime;k++){
			for(l=0; l<MC_strps_persite/SpanTime;l++)
				Connectmatrix[k][l] = 0;
		}
		Mulmatrix();

		/* 相空间构型 
		fprintf(fpt_1, "The temperature is %lf\n", Temperature);
		for(k = 0;k<MC_strps_persite/SpanTime;k++){
			for(l=0; l<MC_strps_persite/SpanTime;l++)
				fprintf(fpt_1, "%lf\t", Connectmatrix[k][l]);
			fprintf(fpt_1, "\n\n");
		}
		*/

		MatrixXd Name = MatrixXd::Constant(MC_strps_persite/SpanTime,MC_strps_persite/SpanTime,0.0);
		//VectorXcd v;
		
		for(k = 0;k<MC_strps_persite/SpanTime;k++){
			for(l=0; l<MC_strps_persite/SpanTime;l++)
				Name(k,l) = Connectmatrix[k][l];
		}

		SelfAdjointEigenSolver<MatrixXd> es(Name);

		//cout<<"The eigenvalues of A are:"<<endl<<es.eigenvalues()<<endl;
		//cout<<"The matrix of eigenvectors, V, is:"<<endl<<es.eigenvectors()<<endl<<endl;

		double eigen_values[MC_strps_persite/SpanTime];
		//double eigen_vactors[MC_strps_persite/SpanTime][MC_strps_persite/SpanTime];
		
		for(k=0; k<(Q*3);k++){
			//v = es.eigenvectors().col(MC_strps_persite/SpanTime-k-1);
			eigen_values[k] = es.eigenvalues()(MC_strps_persite/SpanTime-k-1);
			//eigen_vactors[k][l] = v(l);
		}	
		
		
		//fprintf(fpt_2, "The temperature is %lf\n", Temperature);
		for(k=0; k<(Q*3);k++)
			outfile <<setiosflags(ios::fixed)<<setprecision(8)<< eigen_values[k] <<" " ;

		outfile <<endl;
		
	}
	outfile.close();

 	MPI_Finalize();
	return 0;
}